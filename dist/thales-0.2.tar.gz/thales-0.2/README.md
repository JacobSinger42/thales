# thales
 A light-weight Cartesian graphing library using PyGame
